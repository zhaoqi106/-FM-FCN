'''
    人脸检测算法，参考代码：https://github.com/Linzaer/Ultra-Light-Fast-Generic-Face-Detector-1MB
'''

import sys, os
import cv2
from face_detect.vision.ssd.config.fd_config import define_img_size
from face_detect.vision.utils.misc import Timer


class FaceDetect:
    def __init__(self, net_type="RFB", input_size=640, threshold=0.7, candidate_size=1000, test_device="cuda:0"):
        '''
            net_type:       The network architecture ,optional: RFB (higher precision) or slim (faster)
            input_size:     define network input size,default optional value 128/160/320/480/640/1280
            threshold:      score threshold
            candidate_size: nms candidate size
            test_device:    cuda:0 or cpu
        '''
        self.m_net_type = net_type
        self.m_input_size = input_size
        self.m_threshold = threshold
        self.m_candidate_size = candidate_size
        self.m_test_device = test_device

        if self.buildModel() != 0:
            raise ValueError('模型构建失败')

    def buildModel(self):
        '''
        模型构建
        Returns:
                0：  成功
                -1： 失败
        '''
        class_names = ['BACKGROUND', 'face']
        define_img_size(self.m_input_size)
        from face_detect.vision.ssd.mb_tiny_fd import create_mb_tiny_fd, create_mb_tiny_fd_predictor
        from face_detect.vision.ssd.mb_tiny_RFB_fd import create_Mb_Tiny_RFB_fd, create_Mb_Tiny_RFB_fd_predictor
        if self.m_net_type == 'slim':
            if self.m_input_size <= 320:
                model_path = "face_detect/models/pretrained/version-slim-320.pth"
            else:
                model_path = "face_detect/models/pretrained/version-slim-640.pth"
            net = create_mb_tiny_fd(len(class_names), is_test=True, device=self.m_test_device)
            self.m_predictor = create_mb_tiny_fd_predictor(net, candidate_size=self.m_candidate_size, device=self.m_test_device)
        elif self.m_net_type == 'RFB':
            if self.m_input_size <= 320:
                model_path = "face_detect/models/pretrained/version-RFB-320.pth"
            else:
                model_path = "face_detect/models/pretrained/version-RFB-640.pth"
            net = create_Mb_Tiny_RFB_fd(len(class_names), is_test=True, device=self.m_test_device)
            self.m_predictor = create_Mb_Tiny_RFB_fd_predictor(net, candidate_size=self.m_candidate_size, device=self.m_test_device)
        else:
            print("The net type is wrong!")
            return -1
        net.load(model_path)
        return 0

    def getFaceLoc(self, orig_image):
        '''
        人脸检测，返回人脸坐标
        Args:
            orig_image: BGR格式图像
        Returns:
            boxes:  类别框     [[x1, y1, x2, y2], ...]
            labels: 类别索引    [1, 2, ...]
            probs:  类别概率    [0.9, 1.0, ...]
        '''
        image = cv2.cvtColor(orig_image, cv2.COLOR_BGR2RGB)
        boxes, labels, probs = self.m_predictor.predict(image, self.m_candidate_size / 2, self.m_threshold)
        return boxes.numpy(), labels.numpy(), probs.numpy()

    def videoFaceDetect(self, video):
        cap = cv2.VideoCapture(video)
        timer = Timer()
        sum = 0
        while True:
            ret, orig_image = cap.read()
            if orig_image is None:
                print("Read video end!")
                break 
            timer.start()
            boxes, labels, probs = self.getFaceLoc(orig_image)
            interval = timer.end()
            fps = f"FPS: {1/interval: .1f}"
            cv2.putText(orig_image, fps,
                        (0, 20),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.5,  # font scale
                        (0, 0, 255),  # color
                        2)  # line type
            for i in range(len(boxes)):
                box = boxes[i, :]
                label = f" {probs[i]:.2f}"
                cv2.rectangle(orig_image,
                              (round(box[0]), round(box[1])),  # x1, y1
                              (round(box[2]), round(box[3])),  # x2, y2
                              (0, 255, 0),  # color
                              4)            # line thickness
                cv2.putText(orig_image, label,
                            (round(box[0]), round(box[1]) - 10),
                            cv2.FONT_HERSHEY_SIMPLEX,
                            0.5,            # font scale
                            (0, 0, 255),    # color
                            2)              # line type

            orig_image = cv2.resize(orig_image, None, None, fx=0.8, fy=0.8)
            sum += len(boxes)
            cv2.imshow('face detect[Please press Q if you want to quit.]', orig_image)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
        cap.release()
        cv2.destroyAllWindows()
        print("all face num:{}".format(sum))
